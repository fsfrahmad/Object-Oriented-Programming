﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Lab_07
{
    public class FireChief : FireFighter
    {
        public FireChief(string name, FireTruck MyTruck): base (name, MyTruck)
        {

        }
        public void DelgateTask()
        {

        }
    }
}
